import tkinter as tk
from tkinter import ttk, filedialog, messagebox, scrolledtext
import os
import subprocess
import shutil
import threading
import json
import re

CONFIG_FILE = "config_local_v2.json"

class XTransferUltimate(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("XConvert_Ultimate_OGXBOX (Dual Engine) v1.0.0 - por Deilan-glitch")
        self.geometry("760x860") # Un poco más alto para la nueva casilla
        
        # --- Variables de estado ---
        self.lista_juegos = [] 
        self.tema_oscuro = True # Variable de estado del tema
        
        self.xgdtool_path = tk.StringVar(value=os.path.join(os.getcwd(), "XGDTool-v1.0.0-win-x64-CLI.exe"))
        self.extract_xiso_path = tk.StringVar(value=os.path.join(os.getcwd(), "extract-xiso.exe"))
        
        self.modo_operacion = tk.StringVar(value="Comprimir a CCI + Attacher")
        self.dest_path_display = tk.StringVar()
        self.usar_etiquetas = tk.BooleanVar(value=True)
        self.forzar_rewrite = tk.BooleanVar(value=False) # Nueva variable para Rewrite
        
        self.cargar_configuracion()
        
        # Inicializar el tema antes de crear la interfaz
        style = ttk.Style()
        style.theme_use('clam')
        self.aplicar_tema()
        
        self.crear_interfaz()
        
        self.protocol("WM_DELETE_WINDOW", self.al_cerrar)

    # --- MOTOR DE TEMAS ---
    def aplicar_tema(self):
        style = ttk.Style()
        if self.tema_oscuro:
            bg_main = '#1e1e1e'
            fg_main = '#e0e0e0'
            bg_btn = '#3a3a3a'
            fg_btn = '#ffffff'
            border = '#555555'
            active_btn = '#4a4a4a'
            pressed_btn = '#2a2a2a'
            self.configure(bg=bg_main)
        else:
            bg_main = '#f0f0f0'
            fg_main = '#000000'
            bg_btn = '#e0e0e0'
            fg_btn = '#000000'
            border = '#cccccc'
            active_btn = '#d0d0d0'
            pressed_btn = '#b0b0b0'
            self.configure(bg=bg_main)

        style.configure('.', background=bg_main, foreground=fg_main)
        style.configure('TFrame', background=bg_main)
        style.configure('TLabelFrame', background=bg_main, bordercolor=border, titlecolor=fg_main)
        style.configure('TButton', background=bg_btn, foreground=fg_btn, bordercolor=border, focuscolor=border)
        style.map('TButton', background=[('active', active_btn), ('pressed', pressed_btn)])
        style.configure('TEntry', background=bg_main, foreground=fg_main, fieldbackground=bg_main, bordercolor=border)
        
        style.configure('TCombobox', background=bg_main, foreground=fg_main, fieldbackground=bg_main, bordercolor=border)
        style.map('TCombobox', 
                  fieldbackground=[('readonly', bg_main)],
                  selectbackground=[('readonly', '#0078d7')],
                  selectforeground=[('readonly', 'white')])
                  
        style.configure('TCheckbutton', background=bg_main, foreground=fg_main)
        style.configure('Vertical.TScrollbar', background=bg_btn, troughcolor=bg_main, arrowcolor=fg_main)
        style.configure("TProgressbar", troughcolor=bg_btn, background='#0078d7', bordercolor=bg_main, lightcolor='#0078d7', darkcolor='#0078d7')

    def alternar_tema(self):
        self.tema_oscuro = not self.tema_oscuro
        self.aplicar_tema()
        self.actualizar_colores_lista() 
        
        if self.tema_oscuro:
            self.btn_tema.config(text="☀️ Modo Claro")
            self.log_area.config(bg="#121212", fg="#00FF00")
            self.listbox.config(bg="#2b2b2b", fg="#e0e0e0", selectbackground="#0078d7", selectforeground="white")
        else:
            self.btn_tema.config(text="🌙 Modo Oscuro")
            self.log_area.config(bg="#ffffff", fg="#006600") 
            self.listbox.config(bg="#ffffff", fg="#000000", selectbackground="#0078d7", selectforeground="white")

    # --- LÓGICA DE PROGRAMA ---
    def cargar_configuracion(self):
        if os.path.exists(CONFIG_FILE):
            try:
                with open(CONFIG_FILE, 'r') as f:
                    config = json.load(f)
                    self.xgdtool_path.set(config.get("xgd_path", self.xgdtool_path.get()))
                    self.extract_xiso_path.set(config.get("exiso_path", self.extract_xiso_path.get()))
                    self.modo_operacion.set(config.get("modo", self.modo_operacion.get()))
                    self.dest_path_display.set(config.get("dest_path", self.dest_path_display.get()))
                    self.usar_etiquetas.set(config.get("etiquetas", True))
                    self.forzar_rewrite.set(config.get("rewrite", False))
            except Exception:
                pass

    def guardar_configuracion(self):
        config = {
            "xgd_path": self.xgdtool_path.get(),
            "exiso_path": self.extract_xiso_path.get(),
            "modo": self.modo_operacion.get(),
            "dest_path": self.dest_path_display.get(),
            "etiquetas": self.usar_etiquetas.get(),
            "rewrite": self.forzar_rewrite.get()
        }
        try:
            with open(CONFIG_FILE, 'w') as f:
                json.dump(config, f, indent=4)
        except Exception:
            pass

    def al_cerrar(self):
        self.guardar_configuracion()
        self.destroy()

    def crear_interfaz(self):
        frame_top = ttk.Frame(self)
        frame_top.pack(fill="x", pady=(0, 5))
        self.btn_tema = ttk.Button(frame_top, text="☀️ Modo Claro", command=self.alternar_tema)
        self.btn_tema.pack(side="right")

        frame_rutas = ttk.LabelFrame(self, text=" 1. Lista de Juegos a Procesar (PC) ", padding=10)
        frame_rutas.pack(fill="x", pady=5)
        
        self.listbox = tk.Listbox(frame_rutas, height=6, width=65, selectmode=tk.EXTENDED,
                                  bg="#2b2b2b", fg="#e0e0e0",
                                  selectbackground="#0078d7", selectforeground="white")
        self.listbox.grid(row=0, column=0, rowspan=4, padx=5, pady=5, sticky="nsew")
        
        scrollbar = ttk.Scrollbar(frame_rutas, orient="vertical", command=self.listbox.yview)
        scrollbar.grid(row=0, column=1, rowspan=4, sticky="ns")
        self.listbox.configure(yscrollcommand=scrollbar.set)
        
        ttk.Button(frame_rutas, text="+ Añadir Archivos (ISO/XISO)", command=self.agregar_iso).grid(row=0, column=2, padx=10, pady=2, sticky="ew")
        ttk.Button(frame_rutas, text="+ Añadir Carpetas (CCI/HDD)", command=self.agregar_carpetas).grid(row=1, column=2, padx=10, pady=2, sticky="ew")
        ttk.Button(frame_rutas, text="❌ Quitar Seleccionado", command=self.quitar_seleccion).grid(row=2, column=2, padx=10, pady=2, sticky="ew")
        ttk.Button(frame_rutas, text="🗑 Limpiar Lista", command=self.limpiar_lista).grid(row=3, column=2, padx=10, pady=2, sticky="ew")
        
        ttk.Label(frame_rutas, text="Motor CCI (XGDTool):").grid(row=4, column=0, sticky="w", pady=(10,0), padx=5)
        frame_xgd = ttk.Frame(frame_rutas)
        frame_xgd.grid(row=5, column=0, columnspan=3, sticky="ew", padx=5)
        ttk.Entry(frame_xgd, textvariable=self.xgdtool_path, width=70).pack(side=tk.LEFT, fill="x", expand=True)
        ttk.Button(frame_xgd, text="Examinar", command=lambda: self.seleccionar_herramienta(self.xgdtool_path)).pack(side=tk.LEFT, padx=5)
        
        ttk.Label(frame_rutas, text="Motor FATX/LBA (extract-xiso):").grid(row=6, column=0, sticky="w", pady=(5,0), padx=5)
        frame_ex = ttk.Frame(frame_rutas)
        frame_ex.grid(row=7, column=0, columnspan=3, sticky="ew", padx=5)
        ttk.Entry(frame_ex, textvariable=self.extract_xiso_path, width=70).pack(side=tk.LEFT, fill="x", expand=True)
        ttk.Button(frame_ex, text="Examinar", command=lambda: self.seleccionar_herramienta(self.extract_xiso_path)).pack(side=tk.LEFT, padx=5)
        
        frame_destino = ttk.LabelFrame(self, text=" 2. Conversión y Destino (Unidad FATXplorer) ", padding=10)
        frame_destino.pack(fill="x", pady=5)
        
        ttk.Label(frame_destino, text="Convertir todo a:").grid(row=0, column=0, sticky="w", pady=5)
        opciones_salida = ["Extraer a HDD Ready", "Comprimir a CCI + Attacher", "Crear imagen XISO"]
        cb_modo = ttk.Combobox(frame_destino, textvariable=self.modo_operacion, values=opciones_salida, width=30, state="readonly")
        cb_modo.grid(row=0, column=1, sticky="w", padx=5)
        cb_modo.bind("<<ComboboxSelected>>", self.actualizar_colores_lista)
        
        ttk.Checkbutton(frame_destino, text="Añadir etiqueta origen (Ej. [Src_CCI])", variable=self.usar_etiquetas).grid(row=0, column=2, sticky="w", padx=5)
        
        # NUEVA CASILLA PARA REWRITE
        ttk.Checkbutton(frame_destino, text="Forzar Rewrite (Optimizar XISO)", variable=self.forzar_rewrite, command=self.actualizar_colores_lista).grid(row=1, column=2, sticky="w", padx=5)
        
        ttk.Label(frame_destino, text="Carpeta Destino:").grid(row=2, column=0, sticky="w", pady=5)
        ttk.Entry(frame_destino, textvariable=self.dest_path_display, width=55, state="readonly").grid(row=2, column=1, padx=5)
        ttk.Button(frame_destino, text="Elegir Destino", command=self.seleccionar_destino).grid(row=2, column=2, pady=5)
        
        self.btn_iniciar = ttk.Button(self, text="Iniciar Pipeline Dual Engine", command=self.iniciar_proceso)
        self.btn_iniciar.pack(pady=10, fill="x")

        self.progress_var = tk.DoubleVar()
        self.progress_bar = ttk.Progressbar(self, variable=self.progress_var, maximum=100, mode='determinate')
        self.progress_bar.pack(fill="x", pady=(0, 10))
        
        self.log_area = scrolledtext.ScrolledText(self, height=12, bg="#121212", fg="#00FF00", font=("Consolas", 9))
        self.log_area.pack(fill="both", expand=True)
        self.log("XConvert_Ultimate_OGXBOX v1.0.0 Iniciado.\nXGDTool y extract-xiso listos para el trabajo.\n")
        
        self.actualizar_colores_lista()

    def identificar_tipo_iso(self, ruta):
        try:
            with open(ruta, 'rb') as f:
                f.seek(0x10000)
                magic = f.read(20)
                if magic == b'MICROSOFT*XBOX*MEDIA':
                    return "XISO"
        except Exception:
            pass
        return "STD_ISO" 

    def actualizar_colores_lista(self, event=None):
        modo = self.modo_operacion.get()
        for i, juego in enumerate(self.lista_juegos):
            input_type = juego["tipo"]
            es_redundante = False
            
            if (input_type == "XISO" and "XISO" in modo) or \
               (input_type == "HDD" and ("HDD" in modo or "Extraer" in modo)) or \
               (input_type == "CCI" and "CCI" in modo):
                es_redundante = True
                
            # Bypass de redundancia si el usuario marca "Forzar Rewrite"
            if es_redundante and input_type == "XISO" and "XISO" in modo and self.forzar_rewrite.get():
                es_redundante = False
                
            if es_redundante:
                bg_color = '#ff6b6b' if self.tema_oscuro else '#ff9999'
                fg_color = 'white' if self.tema_oscuro else 'black'
                self.listbox.itemconfig(i, {'bg': bg_color, 'fg': fg_color})
            else:
                bg_color = '#2b2b2b' if self.tema_oscuro else '#ffffff'
                fg_color = '#e0e0e0' if self.tema_oscuro else '#000000'
                self.listbox.itemconfig(i, {'bg': bg_color, 'fg': fg_color})

    def quitar_seleccion(self):
        seleccionados = self.listbox.curselection()
        if not seleccionados:
            messagebox.showinfo("Aviso", "Selecciona al menos un juego de la lista para quitarlo.")
            return
        for index in reversed(seleccionados):
            self.listbox.delete(index)
            del self.lista_juegos[index]
        self.log(f"[*] {len(seleccionados)} juego(s) removido(s) de la lista.")
        self.actualizar_colores_lista()

    def agregar_iso(self):
        rutas = filedialog.askopenfilenames(filetypes=[("Archivos de Imagen", "*.iso *.xiso")])
        agregados = 0
        duplicados = 0
        for ruta in rutas:
            if any(juego["ruta"] == ruta for juego in self.lista_juegos):
                duplicados += 1
                continue
            nombre = os.path.splitext(os.path.basename(ruta))[0]
            tipo_real = self.identificar_tipo_iso(ruta)
            
            self.lista_juegos.append({"tipo": tipo_real, "ruta": ruta, "nombre_mostrar": nombre})
            self.listbox.insert(tk.END, f"[{tipo_real}] {nombre}")
            agregados += 1
            
        if agregados > 0:
            msg = f"[*] {agregados} ISO(s) añadido(s)."
            if duplicados > 0: msg += f" (Se ignoraron {duplicados} duplicados)."
            self.log(msg)
            self.actualizar_colores_lista()
        elif duplicados > 0:
            self.log(f"[*] Las {duplicados} ISOs seleccionadas ya estaban en la lista.")

    def agregar_carpetas(self):
        directorio = filedialog.askdirectory(title="Selecciona la carpeta de un juego, o tu carpeta raíz con todos tus juegos")
        if not directorio: return
        
        agregados = 0
        duplicados = 0
        def verificar_y_agregar(ruta_juego, tipo_juego, nombre_mostrar):
            nonlocal agregados, duplicados
            if any(juego["ruta"] == ruta_juego for juego in self.lista_juegos):
                duplicados += 1
                return False
            self.lista_juegos.append({"tipo": tipo_juego, "ruta": ruta_juego, "nombre_mostrar": nombre_mostrar})
            self.listbox.insert(tk.END, f"[{tipo_juego}] {nombre_mostrar}")
            agregados += 1
            return True
        def evaluar_carpeta(ruta_carpeta):
            archivos_cci = [f for f in os.listdir(ruta_carpeta) if f.lower().endswith('.cci')]
            if archivos_cci:
                archivo_principal = next((f for f in archivos_cci if ".1.cci" in f.lower()), archivos_cci[0])
                ruta_completa = os.path.join(ruta_carpeta, archivo_principal)
                nombre = os.path.basename(ruta_carpeta)
                verificar_y_agregar(ruta_completa, "CCI", nombre)
                return True
            
            if os.path.exists(os.path.join(ruta_carpeta, "default.xbe")):
                nombre = os.path.basename(ruta_carpeta)
                verificar_y_agregar(ruta_carpeta, "HDD", nombre)
                return True
            return False
            
        if not evaluar_carpeta(directorio):
            for item in os.listdir(directorio):
                subruta = os.path.join(directorio, item)
                if os.path.isdir(subruta):
                    evaluar_carpeta(subruta)
                    
        if agregados > 0:
            msg = f"[*] Escáner completado. {agregados} juego(s) añadido(s)."
            if duplicados > 0: msg += f" (Se omitieron {duplicados} repetidos)."
            self.log(msg)
            self.actualizar_colores_lista()
        elif duplicados > 0:
            self.log(f"[*] Todos los juegos encontrados ({duplicados}) ya estaban cargados en la lista.")
        else:
            messagebox.showwarning("Aviso", "No se detectaron juegos válidos (HDD Ready o carpetas con .cci) en este directorio.")

    def limpiar_lista(self):
        self.listbox.delete(0, tk.END)
        self.lista_juegos.clear()
        self.actualizar_colores_lista()

    def seleccionar_herramienta(self, variable_tk):
        ruta = filedialog.askopenfilename(filetypes=[("Ejecutables", "*.exe")])
        if ruta: variable_tk.set(ruta)
        
    def seleccionar_destino(self):
        ruta = filedialog.askdirectory(title="Selecciona la carpeta base en tu Xbox montada (ej. X:\\Games)")
        if ruta: self.dest_path_display.set(ruta)

    def log(self, mensaje):
        self.log_area.insert(tk.END, mensaje + "\n")
        self.log_area.see(tk.END)

    def leer_titulo_xbe(self, xbe_path):
        try:
            with open(xbe_path, 'rb') as f:
                if f.read(4) != b'XBEH': return None
                f.seek(0x0104)
                base_addr = int.from_bytes(f.read(4), 'little')
                f.seek(0x0118)
                cert_addr = int.from_bytes(f.read(4), 'little')
                cert_offset = cert_addr - base_addr
                f.seek(cert_offset + 0x000C)
                title_bytes = f.read(80)
                title = title_bytes.decode('utf-16le').split('\x00')[0]
                title = re.sub(r'[<>:"/\\|?*]', '', title).strip()
                return title if title else None
        except Exception:
            return None

    def actualizar_progreso(self, valor):
        self.after(0, lambda: self.progress_var.set(valor))

    def iniciar_proceso(self):
        if not self.lista_juegos:
            messagebox.showerror("Error", "Añade al menos un juego a la lista.")
            return
        xgd_tool = self.xgdtool_path.get()
        ex_tool = self.extract_xiso_path.get()
        if not os.path.exists(xgd_tool) or not os.path.exists(ex_tool):
            messagebox.showerror("Error", "Falta la ruta a XGDTool o extract-xiso.exe.")
            return
        dest = self.dest_path_display.get()
        if not os.path.isdir(dest):
            messagebox.showerror("Error", "Selecciona una carpeta de destino válida.")
            return
        self.guardar_configuracion()
        self.btn_iniciar.config(state="disabled")
        self.log("==================================================")
        hilo = threading.Thread(target=self.proceso_backend, args=(xgd_tool, ex_tool, dest))
        hilo.start()

    def proceso_backend(self, xgd_tool, ex_tool, destino_base):
        total_juegos = len(self.lista_juegos)
        modo = self.modo_operacion.get()
        
        for indice, juego in enumerate(self.lista_juegos, 1):
            self.actualizar_progreso(0)
            
            input_path = juego["ruta"]
            input_type = juego["tipo"]
            original_name = juego["nombre_mostrar"]
            
            tag_origen = ""
            if self.usar_etiquetas.get():
                if input_type == "XISO": tag_origen = " [Src_XISO]"
                elif input_type == "STD_ISO": tag_origen = " [Src_ISO]"
                elif input_type == "HDD": tag_origen = " [Src_HDD]"
                elif input_type == "CCI": tag_origen = " [Src_CCI]"

            # Nueva Etiqueta Inteligente de Rewrite
            tag_rewrite = ""
            if input_type == "XISO" and "XISO" in modo and self.forzar_rewrite.get():
                tag_rewrite = " [Rewrite]"
                
            safe_temp_name = re.sub(r'[<>:"/\\|?*]', '', original_name)[:15].strip()
            temp_work_dir = os.path.join(destino_base, f"xt_temp_{safe_temp_name}")
            
            self.log(f"\n---> PROCESANDO JUEGO {indice} DE {total_juegos}: [{input_type}] {original_name}")
            
            es_redundante = False
            if (input_type == "XISO" and "XISO" in modo) or \
               (input_type == "HDD" and ("HDD" in modo or "Extraer" in modo)) or \
               (input_type == "CCI" and "CCI" in modo):
                es_redundante = True
                
            # Bypass Redundancia si Forzar Rewrite está activo
            if es_redundante and input_type == "XISO" and "XISO" in modo and self.forzar_rewrite.get():
                es_redundante = False
                
            if es_redundante:
                self.log("  [!] Formato redundante detectado. Omitiendo la conversión de este juego (Lista Roja).")
                self.actualizar_progreso(100)
                continue 
                
            try:
                if os.path.exists(temp_work_dir):
                    shutil.rmtree(temp_work_dir, ignore_errors=True)
                os.makedirs(temp_work_dir, exist_ok=True)
                iso_maestra = None
                
                self.log(f"  [1/3] Normalizando origen...")
                self.actualizar_progreso(15)
                
                if input_type in ["XISO", "STD_ISO"]:
                    iso_maestra = input_path
                    self.log(f"  [*] Origen {input_type} detectado. Omitiendo conversión previa.")
                    
                elif input_type == "HDD":
                    self.log("  [*] Motor: extract-xiso (Construyendo mapa de sectores LBA...)")
                    subprocess.run([ex_tool, "-c", os.path.abspath(input_path)], cwd=temp_work_dir, capture_output=True, text=True)
                    for root, dirs, files in os.walk(temp_work_dir):
                        for f in files:
                            if f.lower().endswith('.iso'):
                                iso_maestra = os.path.join(root, f)
                                break
                        if iso_maestra: break
                    if not iso_maestra:
                        raise Exception("extract-xiso falló al generar la ISO desde HDD.")
                        
                elif input_type == "CCI":
                    self.log("  [*] Motor: XGDTool (Descomprimiendo CCI a ISO pura...)")
                    subprocess.run([xgd_tool, "--xiso", "--offline", os.path.abspath(input_path), temp_work_dir], cwd=temp_work_dir, capture_output=True, text=True)
                    for root, dirs, files in os.walk(temp_work_dir):
                        for f in files:
                            if f.lower().endswith(('.iso', '.xiso')):
                                iso_maestra = os.path.join(root, f)
                                break
                        if iso_maestra: break
                    if not iso_maestra:
                        raise Exception("XGDTool falló al descomprimir el CCI.")
                        
                self.log(f"  [2/3] Generando formato final ({modo})...")
                self.actualizar_progreso(45)
                
                if "XISO" in modo:
                    safe_name = re.sub(r'[<>:"/\\|?*]', '', original_name).strip()
                    ruta_final = os.path.join(destino_base, f"{safe_name}{tag_origen}{tag_rewrite}.iso")
                    
                    contador = 1
                    while os.path.exists(ruta_final):
                        ruta_final = os.path.join(destino_base, f"{safe_name}{tag_origen}{tag_rewrite}_XT_{contador}.iso")
                        contador += 1
                        
                    # Tratamiento VIP: Scrubbing para STD_ISO o para XISO si el Rewrite está forzado
                    if input_type == "STD_ISO" or (input_type == "XISO" and self.forzar_rewrite.get()):
                        self.log("  [*] Motor: extract-xiso (Scrubbing: Optimizando y limpiando a XISO puro...)")
                        
                        subprocess.run([ex_tool, "-x", os.path.abspath(iso_maestra)], cwd=temp_work_dir, capture_output=True, text=True)
                        
                        source_files_dir = None
                        for item in os.listdir(temp_work_dir):
                            item_path = os.path.join(temp_work_dir, item)
                            if os.path.isdir(item_path) and os.path.exists(os.path.join(item_path, "default.xbe")):
                                source_files_dir = item_path
                                break
                        if not source_files_dir:
                            raise Exception("extract-xiso falló al extraer el disco para el Scrubbing.")
                            
                        self.actualizar_progreso(65)
                        
                        subprocess.run([ex_tool, "-c", source_files_dir], cwd=temp_work_dir, capture_output=True, text=True)
                        iso_generada = source_files_dir + ".iso"
                        if not os.path.exists(iso_generada):
                            raise Exception("extract-xiso falló al reconstruir el XISO optimizado.")
                            
                        shutil.move(iso_generada, ruta_final)
                    
                    elif input_type == "XISO":
                        shutil.copy(iso_maestra, ruta_final)
                    else:
                        shutil.move(iso_maestra, ruta_final)
                        
                    self.actualizar_progreso(85)
                    self.log(f"  [OK] XISO finalizado: {os.path.basename(ruta_final)}")
                    
                elif "HDD" in modo or "Extraer" in modo:
                    limite_nombre = 42 - len(tag_origen)
                    
                    self.log("  [*] Motor: extract-xiso (Extrayendo archivos de forma segura...)")
                    subprocess.run([ex_tool, "-x", os.path.abspath(iso_maestra)], cwd=temp_work_dir, capture_output=True, text=True)
                    self.actualizar_progreso(85)
                    
                    source_files_dir = None
                    for item in os.listdir(temp_work_dir):
                        item_path = os.path.join(temp_work_dir, item)
                        if os.path.isdir(item_path) and os.path.exists(os.path.join(item_path, "default.xbe")):
                            source_files_dir = item_path
                            break
                    if not source_files_dir:
                        raise Exception("extract-xiso no pudo extraer la imagen correctamente.")
                        
                    xbe_file = os.path.join(source_files_dir, "default.xbe")
                    
                    carpeta_destino = re.sub(r'[<>:"/\\|?*]', '', original_name)[:limite_nombre].strip()
                    titulo_interno = self.leer_titulo_xbe(xbe_file)
                    if titulo_interno:
                        carpeta_destino = titulo_interno[:limite_nombre].strip()
                        self.log(f"  [*] Título original detectado: '{carpeta_destino}'")
                        
                    carpeta_destino += tag_origen
                    final_dest = os.path.join(destino_base, carpeta_destino)
                    contador = 1
                    while os.path.exists(final_dest):
                        final_dest = os.path.join(destino_base, f"{carpeta_destino}_XT_{contador}")
                        contador += 1
                    shutil.move(source_files_dir, final_dest)
                    self.log(f"  [OK] HDD Ready finalizado en: {final_dest}")
                    
                elif "CCI" in modo:
                    limite_nombre = 42 - len(tag_origen)
                    
                    self.log("  [*] Motor: XGDTool (Comprimiendo ISO a CCI y generando Attacher...)")
                    subprocess.run([xgd_tool, "--cci", "--attach-xbe", "--offline", os.path.abspath(iso_maestra), temp_work_dir], cwd=temp_work_dir, capture_output=True, text=True)
                    self.actualizar_progreso(85)
                    
                    archivos_cci_utiles = []
                    xbe_esperado = None
                    
                    for root, dirs, files in os.walk(temp_work_dir):
                        for f in files:
                            if f.lower().endswith('.cci'):
                                archivos_cci_utiles.append(os.path.join(root, f))
                            elif f.lower() == 'default.xbe':
                                xbe_esperado = os.path.join(root, f)
                    if not xbe_esperado:
                        self.log(f"  [*] Forzando generación de Attacher a partir de ISO maestra...")
                        subprocess.run([xgd_tool, "--xbe", "--offline", os.path.abspath(iso_maestra), temp_work_dir], cwd=temp_work_dir, capture_output=True, text=True)
                        for root, _, files in os.walk(temp_work_dir):
                            for f in files:
                                if f.lower() == 'default.xbe':
                                    xbe_esperado = os.path.join(root, f)
                                    break
                        if not xbe_esperado:
                            xbe_fantasma_1 = os.path.join(os.getcwd(), "default.xbe")
                            xbe_fantasma_2 = os.path.join(os.path.dirname(xgd_tool), "default.xbe")
                            if os.path.exists(xbe_fantasma_1): xbe_esperado = xbe_fantasma_1
                            elif os.path.exists(xbe_fantasma_2): xbe_esperado = xbe_fantasma_2
                    if not archivos_cci_utiles:
                        raise Exception("XGDTool falló críticamente al crear el archivo .cci.")
                    carpeta_destino = re.sub(r'[<>:"/\\|?*]', '', original_name)[:limite_nombre].strip()
                    if xbe_esperado and os.path.exists(xbe_esperado):
                        self.log("  [OK] Attacher localizado y asegurado.")
                        titulo_interno = self.leer_titulo_xbe(xbe_esperado)
                        if titulo_interno:
                            carpeta_destino = titulo_interno[:limite_nombre].strip()
                            self.log(f"  [*] Título original detectado: '{carpeta_destino}'")
                    else:
                        self.log("  [!] Advertencia crítica: XGDTool no generó el Attacher.")
                        
                    carpeta_destino += tag_origen
                    final_dest = os.path.join(destino_base, carpeta_destino)
                    contador = 1
                    while os.path.exists(final_dest):
                        final_dest = os.path.join(destino_base, f"{carpeta_destino}_XT_{contador}")
                        contador += 1
                        
                    os.makedirs(final_dest, exist_ok=True)
                    
                    for cci in archivos_cci_utiles:
                        shutil.move(cci, os.path.join(final_dest, os.path.basename(cci)))
                        
                    if xbe_esperado and os.path.exists(xbe_esperado):
                        shutil.move(xbe_esperado, os.path.join(final_dest, "default.xbe"))
                        
                    self.log(f"  [OK] CCI finalizado en: {final_dest}")
            except Exception as e:
                self.log(f"  [ERROR] Pipeline interrumpido:\n  {e}")
            
            finally:
                if not es_redundante:
                    self.log(f"  [3/3] Desmontando entorno temporal y limpiando residuos...")
                    if os.path.exists(temp_work_dir):
                        shutil.rmtree(temp_work_dir, ignore_errors=True)
                    self.actualizar_progreso(100)

        self.actualizar_progreso(0)
        self.log("\n==================================================")
        self.log(f"====== PROCESO MASIVO FINALIZADO ({total_juegos} Juego/s) ======\n")
        self.after(0, lambda: self.btn_iniciar.config(state="normal"))

if __name__ == "__main__":
    app = XTransferUltimate()
    app.mainloop()